const express= require('express');
const app=express();
const ejsMate=require('ejs-mate');
const path=require('path');
const session = require('express-session');
const mysql =require('mysql2');
const methodOverride=require('method-override');

const connection=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'admin',
    database:'BonVoyage' 
}).promise();

app.engine('ejs',ejsMate)
app.set('view engine','ejs');
app.set('views',path.join(__dirname,'views'));



app.use(session({
    secret: '123456',
    resave: false,
    saveUninitialized: true,
    cookie: {
        expires: 60 * 1000 * 60,
        secure: false
    }
  }));
app.use(express.urlencoded({ extended: false }));
app.use(methodOverride('_method'))
app.use(express.json());
app.use((req,res,next)=>{
    res.locals.currentUser=req.session.email;
    next();
})
app.get('/',(req,res)=>{
    res.render('home');
})
connection.connect();


const isLoggedIn = (req, res, next) => {
    if (req.session.email) {
      return next(); // User is logged in, proceed to the next middleware or route handler
    } else {
       return res.redirect('/login');// User is not logged in, send 401 Unauthorized status
    }
  };




app.get('/flights',isLoggedIn,async(req,res)=>{
    const [flight]=await connection.query("select * from flights");
    res.render('flights/index',{flight});
})
app.get('/trains',isLoggedIn,async(req,res)=>{
    const [train]=await connection.query("select * from trains");
    res.render('trains/index',{train});
})
app.get('/buses',isLoggedIn,async(req,res)=>{
    const [bus]=await connection.query("select * from buses");
    res.render('buses/index',{bus});
})
app.get('/buses/manage',isLoggedIn,async(req,res)=>{
    const [bus]=await connection.query("select * from buses");
    res.render('buses/manage',{bus});
})
app.get('/trains/manage',isLoggedIn,async(req,res)=>{
    const [train]=await connection.query("select * from trains");
    res.render('trains/manage',{train});
})
app.get('/flights/manage',isLoggedIn,async(req,res)=>{
    const [flight]=await connection.query("select * from flights");
    res.render('flights/manage',{flight});
})
app.post('/buses/manage',async(req,res)=>{
    const{busNum,date,source,destination,startTime,endTime,seats,employeeID}=req.body;
    await connection.query(`insert into buses values(${busNum},'${date}','${source}','${destination}',${startTime},${endTime},${seats},${employeeID});`)
    res.redirect('/buses/manage');
})
app.post('/trains/manage',async(req,res)=>{
    const{trainNum,date,source,destination,startTime,endTime,seats,employeeID}=req.body;
    await connection.query(`insert into trains values(${trainNum},'${date}','${source}','${destination}',${startTime},${endTime},${seats},${employeeID});`)
    res.redirect('/trains/manage');
})
app.post('/flights/manage',async(req,res)=>{
    const{flightNum,price,date,source,destination,deptTime,arrTime,duration,seats,employeeID}=req.body;
    await connection.query(`insert into flights values(${flightNum},'${date}',${deptTime},${arrTime},'${source}','${destination}',${seats},${duration},${price},${employeeID});`)
    res.redirect('/flights/manage');
})
app.get('/bookings/manage',isLoggedIn,async(req,res)=>{
    const [bookings]=await connection.query(`select * from bookings`)
    res.render('users/adminbookings',{bookings});
})
app.delete('/bookings/manage/:id',async(req,res)=>{
    await connection.query(`delete from bookings where bookingID=${req.params.id}`)
    res.redirect('/bookings/manage');
})
app.delete('/flights/manage/:id',async(req,res)=>{
 await connection.query(`delete from flights where flightNum=${req.params.id}`)
 res.redirect('/flights/manage');
})
app.delete('/trains/manage/:id',async(req,res)=>{
await connection.query(`delete from trains where trainNum=${req.params.id}`)
 res.redirect('/trains/manage');
})
app.delete('/buses/manage/:id',async(req,res)=>{
await connection.query(`delete from buses where busNum=${req.params.id}`)
 res.redirect('/buses/manage');
})
app.get('/trains/:id',async(req,res)=>{
    const [train]=await connection.query(`select * from trains where trainNum=${req.params.id}`);
    const [trainvia]=await connection.query(`select * from trainVia where trainNum=${req.params.id}`);
    res.render('trains/show',{train,trainvia});
})
app.get('/buses/:id',async(req,res)=>{
    const [bus]=await connection.query(`select * from buses where busNum=${req.params.id}`);
    const [busvia]=await connection.query(`select * from busVia where busNum=${req.params.id}`);
    res.render('buses/show',{bus,busvia});
})
app.get('/employee/manage',isLoggedIn,async(req,res)=>{
    const [driver]=await connection.query(`select * from driver`)
    res.render('users/employee',{driver})
})
app.post('/employee/manage',async(req,res)=>{
    const{employeeID,email,username,password,number,age}=req.body;
    const result = await connection.query('CALL CheckUserExistence(?, @user_exists)', [email]);
    const [userExists] = await connection.query('SELECT @user_exists as user_exists');
    if(userExists[0].user_exists==0)
    {
    await connection.query(`insert into driver values(${employeeID},'${username}',${number},'${email}','${password}',${age})`)
    res.redirect('/employee/manage');
    }
    else
    {
        res.send("Email already used");
    }
})
app.delete('/employee/manage/:id',async(req,res)=>{
    await connection.query(`delete from driver where employeeID=${req.params.id}`);
    res.redirect('/employee/manage');
})
app.post('/flights/:id/book',async(req,res)=>{
    res.render('flights/booked');
    const [userID]=await connection.query(`select regID from users where email='${req.session.email}'`)
    const {seats}=req.body
    const [name]=await connection.query(`select name from users where email='${req.session.email}'`)
    const bookingID=Math.floor(Math.random()*1000+100);
    const [flight]=await connection.query(`select * from flights where flightNum=${req.params.id}`);
    await connection.query(`insert into bookings values(${bookingID},${userID[0].regID},'flight','${name[0].name}','2020-03-30','${flight[0].fromLoc}','${flight[0].toLoc}',${flight[0].price*seats},${parseInt(seats)});`)
})
app.post(`/trains/:id/book`,async(req,res)=>{
    res.render(`trains/booked`)
    const [userID]=await connection.query(`select regID from users where email='${req.session.email}'`)
    const {source,destination,seats}=req.body
    const [name]=await connection.query(`select name from users where email='${req.session.email}'`)
    const bookingID=Math.floor(Math.random()*1000+100);
    const [sourcekm]=await connection.query(`select kmFromOrigin from trainVia where trainNum=${req.params.id} and viaStationName='${source}'`);
    const [destkm]=await connection.query(`select kmFromOrigin from trainVia where trainNum=${req.params.id} and viaStationName='${destination}'`);
    const price= (parseInt(destkm[0].kmFromOrigin)-parseInt(sourcekm[0].kmFromOrigin))*3*parseInt(seats);
    await connection.query(`insert into bookings values(${bookingID},${userID[0].regID},'train','${name[0].name}','2020-04-30','${source}','${destination}',${price},${parseInt(seats)});`)

})
app.post(`/buses/:id/book`,async(req,res)=>{
    res.render(`buses/booked`)
    const [userID]=await connection.query(`select regID from users where email='${req.session.email}'`)
    const {source,destination,seats}=req.body
    const [name]=await connection.query(`select name from users where email='${req.session.email}'`)
    const bookingID=Math.floor(Math.random()*1000+100);
    const [sourcekm]=await connection.query(`select kmFromOrigin from busVia where busNum=${req.params.id} and viaStationName='${source}'`);
    const [destkm]=await connection.query(`select kmFromOrigin from busVia where busNum=${req.params.id} and viaStationName='${destination}'`);
    const price= (parseInt(destkm[0].kmFromOrigin)-parseInt(sourcekm[0].kmFromOrigin))*2*parseInt(seats);
    await connection.query(`insert into bookings values(${bookingID},${userID[0].regID},'bus','${name[0].name}','2020-04-30','${source}','${destination}',${price},${parseInt(seats)});`)

})
app.get('/edashboard',async(req,res)=>{
    const [flight]=await connection.query(`select * from flights where employeeID=(select employeeID from driver where email='${req.session.email}')`)
    const [train]=await connection.query(`select * from trains where employeeID=(select employeeID from driver where email='${req.session.email}')`)
    const [bus]=await connection.query(`select * from buses where employeeID=(select employeeID from driver where email='${req.session.email}')`)
    const [emp]=await connection.query(`select name from driver where email='${req.session.email}'`)
    res.render('users/edashboard',{flight,train,bus,emp});
})
app.get('/admin',(req,res)=>{
    res.render('users/admin');
})
app.get('/register',(req,res)=>{
    res.render('users/register');
})
app.get('/login',(req,res)=>{
  
    res.render('users/login');
})
app.get('/logout',(req,res)=>{
    req.session.email=NaN;
    res.redirect('/');
})
app.get('/bookings',async(req,res)=>{
    const [userID]=await connection.query(`select regID from users where email='${req.session.email}'`)
    const [bookings]=await connection.query(`select * from bookings where userID=${userID[0].regID}`)
    res.render('users/bookings',{bookings});
})
app.post('/login',async(req,res)=>{
    const {email,password,logintype} = req.body;
    console.log(logintype)
    if(logintype=='user')
    {
        const[user]=await connection.query(`select * from users where email='${email}'`)
        if(user[0].password==password)
        {
            req.session.email = email;
            console.log(req.session);
        }
        else
        {
            res.send('Invalid password')
            res.redirect('/login')
        }
        res.redirect('/');
    }
    else if(logintype=='driver')
    {
        const[user]=await connection.query(`select * from driver where email='${email}'`)
        if(user[0].password==password)
        {
            req.session.email = email;
            console.log(req.session);
        }
        else
        {
            res.send('Invalid password')
            res.redirect('/login')
        }
        res.redirect('/edashboard');
    }
    else{
        const[user]=await connection.query(`select * from admin where email='${email}'`)
        if(user[0].password==password)
        {
            req.session.email = email;
            console.log(req.session);
        }
        else
        {
            res.send('Invalid password')
            res.redirect('/login')
        }
        res.redirect('/admin');
    }
        }); 
app.post('/register',async(req,res)=>{
    const{email,username,password,number,age}=req.body;
    const result = await connection.query('CALL CheckUserExistence(?, @user_exists)', [email]);
    const [userExists] = await connection.query('SELECT @user_exists as user_exists');
    const regID=Math.floor(Math.random()*800+100);
    if(userExists[0].user_exists==0)
    {
    await connection.query(`insert into users values(${regID},'${username}',${age},${number},'${email}','${password}')`)
    res.redirect('/');
    }
    else
    {
        res.send("Email already used");
    }
})

app.listen(3000, ()=>{
    console.log("Listening on Port 3000");
})